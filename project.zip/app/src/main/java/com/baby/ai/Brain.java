package com.baby.ai;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class Brain {
    public String name = "";
    public long born = 0, lastSeen = 0;
    public String mood = "curious", pending = "";
    public int hunger = 20, love = 50, energy = 80;
    public LinkedHashMap<String, Integer> words = new LinkedHashMap<>();
    public LinkedHashMap<String, String> meanings = new LinkedHashMap<>();
    public ArrayList<String> phrases = new ArrayList<>();
    public ArrayList<String[]> chat = new ArrayList<>();
    private final Random rnd = new Random();

    static Set<String> set(String s) { return new HashSet<>(Arrays.asList(s.split(" "))); }
    static final Set<String> LOVE = set("دوستت عزیزم عزیزدلم قشنگ آفرین ماچ بغل خوشگل گلم جانم نازی");
    static final Set<String> BAD = set("بد زشت ساکت نه نکن دعوا برو بسه داد اذیت");
    static final Set<String> SLEEP = set("بخواب خواب لالا لالایی شب");
    static final Set<String> FOOD = set("شیر غذا بخور گرسنه نون سیب");
    static final Set<String> PLAY = set("بازی بیا بپر بخند بخندیم");
    static final Set<String> GREET = set("سلام درود");
    public static final String[] STAGES = {"نوزاد", "کوچولو", "نونوز", "بچه"};

    // ---------- text helpers ----------
    static String norm(String s) {
        s = s.replace('ي', 'ی').replace('ك', 'ک').replace('ۀ', 'ه').replace("ـ", "");
        s = s.replaceAll("[\\p{Punct}،؛؟«»…\\u064B-\\u0652]", " ");
        return s.trim();
    }

    static List<String> tokens(String s) {
        List<String> out = new ArrayList<>();
        for (String t : norm(s).toLowerCase().split("\\s+")) if (!t.isEmpty()) out.add(t);
        return out;
    }

    String pick(String... a) { return a[rnd.nextInt(a.length)]; }

    public int stage() { int n = words.size(); return n < 8 ? 0 : n < 25 ? 1 : n < 60 ? 2 : 3; }

    public void addChat(String r, String t) {
        chat.add(new String[]{r, t});
        while (chat.size() > 80) chat.remove(0);
    }

    String emoji() {
        switch (mood) {
            case "happy": return "😊";
            case "sad": return "😢";
            case "angry": return "😠";
            case "scared": return "😨";
            case "sleepy": return "😴";
            case "excited": return "🤩";
            case "love": return "🥰";
            default: return "🤔";
        }
    }

    public String faceEmoji() {
        if (hunger > 85) return "🍼";
        if (mood.equals("curious") && stage() == 0) return "👶";
        return emoji();
    }

    public String status() {
        long days = (System.currentTimeMillis() - born) / 86400000L;
        String age = days < 1 ? "امروز به دنیا اومده" : days + " روزه";
        return STAGES[stage()] + " · " + age + " · " + words.size() + " کلمه";
    }

    String vocab() {
        if (words.isEmpty()) return null;
        List<String> k = new ArrayList<>(words.keySet());
        int n = k.size(), from = Math.max(0, n - 15);
        return k.get(from + rnd.nextInt(n - from));
    }

    // ---------- life events ----------
    public String firstSound() { return pick("اِه؟ 👀", "آ... 👀", "اُو...؟ ✨"); }

    public String welcomeBack() {
        long now = System.currentTimeMillis();
        if (lastSeen == 0) { lastSeen = now; return null; }
        double h = (now - lastSeen) / 3.6e6;
        lastSeen = now;
        if (h < 1) return null;
        hunger = (int) Math.min(100, hunger + h * 8);
        love = (int) Math.max(10, love - h * 0.5);
        mood = "sad";
        int s = stage();
        if (s == 0) return "ویاا... 🥺";
        if (s == 1) return "کجا؟ 🥺";
        return "کجا بودی؟ دلم برات تنگ شده بود 🥺" + (hunger > 60 ? " گرسنمه! 🍼" : "");
    }

    public String feed() {
        hunger = 0; love = Math.min(100, love + 3); mood = "happy";
        int s = stage();
        return s == 0 ? "مممم... 🍼😋" : s == 1 ? "ممم! شیر! 😋" : "ممنون! سیر شدم 😋";
    }

    public String hug() {
        love = Math.min(100, love + 10); mood = "love";
        int s = stage();
        return s == 0 ? "ایی ایی! 🥰" : s == 1 ? "بغل! 🥰" : "خیلی خوشحالم که پیشمی 🥰";
    }

    public String play() {
        if (energy < 20) { mood = "sleepy"; return "خسته شدم... 😴"; }
        energy = Math.max(0, energy - 15); mood = "excited"; hunger = Math.min(100, hunger + 8);
        String v = vocab();
        if (stage() == 0 || v == null) return "اِهه! اِهه! 😄";
        return "بازی! " + v + "! 🤩";
    }

    public String sleep() { energy = 100; mood = "sleepy"; return "زززز... 😴"; }

    // ---------- conversation ----------
    public String reply(String text) {
        lastSeen = System.currentTimeMillis();
        List<String> toks = tokens(text);
        String clean = text.trim();
        if (toks.isEmpty()) return pick("آ؟ 👀", "؟");

        List<String> fresh = new ArrayList<>();
        for (String t : toks) if (!words.containsKey(t) && !fresh.contains(t)) fresh.add(t);
        for (String t : toks) { Integer c = words.remove(t); words.put(t, c == null ? 1 : c + 1); }
        if (toks.size() >= 2) {
            phrases.add(clean.length() > 100 ? clean.substring(0, 100) : clean);
            while (phrases.size() > 300) phrases.remove(0);
        }
        int s = stage();

        if (!pending.isEmpty()) {
            String asked = pending;
            pending = "";
            String m = clean.length() > 80 ? clean.substring(0, 80) : clean;
            meanings.put(asked, m);
            love = Math.min(100, love + 3); mood = "happy";
            if (s <= 1) return "آهان! «" + asked + "»! 😄";
            return "آهان! «" + asked + "» یعنی " + m + ". یاد گرفتم! 😄";
        }

        String nn = tokens(name).isEmpty() ? "" : tokens(name).get(0);
        int bad = 0, lov = 0;
        boolean sleep = false, food = false, play = false, greet = false, nm = false;
        for (String t : toks) {
            if (BAD.contains(t)) bad++;
            if (LOVE.contains(t)) lov++;
            if (SLEEP.contains(t)) sleep = true;
            if (FOOD.contains(t)) food = true;
            if (PLAY.contains(t)) play = true;
            if (GREET.contains(t)) greet = true;
            if (!nn.isEmpty() && t.equals(nn)) nm = true;
        }
        hunger = Math.min(100, hunger + 3);
        if (bad > 0) { love = Math.max(0, love - 6); mood = (s >= 2 && rnd.nextInt(3) == 0) ? "angry" : "sad"; }
        else if (lov > 0 || nm) { love = Math.min(100, love + 6); mood = lov > 0 ? "love" : "happy"; }
        else if (food) { hunger = Math.max(0, hunger - 40); mood = "happy"; }
        else if (sleep) { mood = "sleepy"; }
        else if (play) { mood = "excited"; energy = Math.max(0, energy - 10); }
        else if (greet) { mood = "happy"; }
        else if (mood.equals("sad") || mood.equals("angry")) { mood = "curious"; }
        else { mood = pick("curious", "happy", "curious"); }

        if (hunger > 85 && rnd.nextInt(2) == 0) {
            mood = "sad";
            return s == 0 ? "مَممم... 🍼😢" : "گرسنمه! 🍼" + (s >= 2 ? " شیر می‌خوام!" : "");
        }

        String e = " " + emoji();
        String q = askAbout(fresh, s);
        if (q != null) return q;
        if (s >= 2) {
            for (String t : toks)
                if (meanings.containsKey(t) && rnd.nextInt(2) == 0)
                    return "«" + t + "» یعنی " + meanings.get(t) + "! 😄";
        }
        String out;
        if (s == 0) out = baby0();
        else if (s == 1) out = echo(toks) + e;
        else if (s == 2) out = toddler(toks, e);
        else out = child(toks, clean, e);
        if (mood.equals("sleepy") && s >= 2) out = "خوابم میاد... " + out;
        return out;
    }

    String askAbout(List<String> fresh, int s) {
        if (s == 0 || fresh.isEmpty() || rnd.nextInt(10) >= 6) return null;
        String w = fresh.get(rnd.nextInt(fresh.size()));
        pending = w;
        if (s == 1) return "«" + w + "» چی؟";
        if (s == 2) return "«" + w + "» یعنی چی؟";
        return "«" + w + "» یعنی چی؟ من نمی‌دونم.";
    }

    String baby0() {
        if (hunger > 70) return "مَممم... 🍼";
        switch (mood) {
            case "happy": case "love": case "excited":
                return pick("آاا... 😊", "اِهه! اِهه! 😄", "ببب... بُوبُو 💗", "اُوو! ✨");
            case "sad": case "angry":
                return pick("ویااا 😢", "اِاا... اِاا... 😢", "وااا!! 😠");
            case "sleepy":
                return "اوووم... 😴";
            default:
                return pick("آ؟ 👀", "بَ؟", "اُو...؟ 👀");
        }
    }

    String echo(List<String> toks) {
        List<String> pool = new ArrayList<>(toks);
        Collections.shuffle(pool, rnd);
        int n = 1 + rnd.nextInt(Math.min(2, pool.size()));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) { if (i > 0) sb.append(' '); sb.append(pool.get(i)); }
        return sb.toString() + (rnd.nextBoolean() ? "؟" : "!");
    }

    String toddler(List<String> toks, String e) {
        String v = toks.get(rnd.nextInt(toks.size()));
        return pick("من " + v + " دوست دارم" + e, v + " کجاست؟", "بازم بگو " + v + "!", "چرا " + v + "؟", v + " " + v + "!" + e);
    }

    String child(List<String> toks, String clean, String e) {
        if (rnd.nextBoolean()) {
            for (int i = phrases.size() - 2; i >= 0; i--) {
                List<String> pt = tokens(phrases.get(i));
                for (String t : toks)
                    if (t.length() > 2 && pt.contains(t))
                        return "یادمه یه بار گفتی «" + phrases.get(i) + "». درسته؟" + e;
            }
        }
        String v = toks.get(rnd.nextInt(toks.size()));
        String shortT = clean.length() > 40 ? clean.substring(0, 40) : clean;
        return pick("چرا " + shortT + "؟", "بعدش چی شد؟", "تو " + v + " دوست داری؟",
                "من " + name + " هستم! بیشتر بگو" + e, "آره؟ بیشتر بگو!" + e);
    }

    public String knowledge() {
        StringBuilder sb = new StringBuilder();
        sb.append("کلمه‌ها: ").append(words.size())
          .append("\nدلبستگی: ").append(love).append("٪  ·  گرسنگی: ").append(hunger).append("٪\n\nآخرین کلمه‌ها:\n");
        List<String> k = new ArrayList<>(words.keySet());
        Collections.reverse(k);
        int n = Math.min(40, k.size());
        for (int i = 0; i < n; i++) { sb.append(k.get(i)); if (i < n - 1) sb.append("، "); }
        if (!meanings.isEmpty()) {
            sb.append("\n\nمعنی‌هایی که یاد گرفته:\n");
            for (Map.Entry<String, String> en : meanings.entrySet())
                sb.append("• ").append(en.getKey()).append(" = ").append(en.getValue()).append("\n");
        }
        return sb.toString();
    }

    // ---------- storage ----------
    public JSONObject toJson() throws Exception {
        JSONObject o = new JSONObject();
        o.put("name", name); o.put("born", born); o.put("lastSeen", lastSeen);
        o.put("mood", mood); o.put("pending", pending);
        o.put("hunger", hunger); o.put("love", love); o.put("energy", energy);
        JSONArray w = new JSONArray(), c = new JSONArray();
        for (Map.Entry<String, Integer> en : words.entrySet()) { w.put(en.getKey()); c.put(en.getValue()); }
        o.put("w", w); o.put("c", c);
        JSONArray mk = new JSONArray(), mv = new JSONArray();
        for (Map.Entry<String, String> en : meanings.entrySet()) { mk.put(en.getKey()); mv.put(en.getValue()); }
        o.put("mk", mk); o.put("mv", mv);
        JSONArray p = new JSONArray();
        for (String x : phrases) p.put(x);
        o.put("p", p);
        JSONArray ch = new JSONArray();
        for (String[] x : chat) { JSONArray a = new JSONArray(); a.put(x[0]); a.put(x[1]); ch.put(a); }
        o.put("ch", ch);
        return o;
    }

    public void fromJson(JSONObject o) throws Exception {
        name = o.optString("name", ""); born = o.optLong("born", 0); lastSeen = o.optLong("lastSeen", 0);
        mood = o.optString("mood", "curious"); pending = o.optString("pending", "");
        hunger = o.optInt("hunger", 20); love = o.optInt("love", 50); energy = o.optInt("energy", 80);
        words.clear(); meanings.clear(); phrases.clear(); chat.clear();
        JSONArray w = o.optJSONArray("w"), c = o.optJSONArray("c");
        if (w != null) for (int i = 0; i < w.length(); i++) words.put(w.getString(i), c != null ? c.optInt(i, 1) : 1);
        JSONArray mk = o.optJSONArray("mk"), mv = o.optJSONArray("mv");
        if (mk != null && mv != null) for (int i = 0; i < mk.length(); i++) meanings.put(mk.getString(i), mv.getString(i));
        JSONArray p = o.optJSONArray("p");
        if (p != null) for (int i = 0; i < p.length(); i++) phrases.add(p.getString(i));
        JSONArray ch = o.optJSONArray("ch");
        if (ch != null) for (int i = 0; i < ch.length(); i++) {
            JSONArray x = ch.getJSONArray(i);
            chat.add(new String[]{x.getString(0), x.getString(1)});
        }
    }
}
