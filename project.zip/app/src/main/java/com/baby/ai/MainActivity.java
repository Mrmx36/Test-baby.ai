package com.baby.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;

public class MainActivity extends Activity {
    Brain b = new Brain();
    SharedPreferences sp;
    LinearLayout msgs;
    ScrollView sv;
    TextView face, title, status;
    EditText input;
    Handler h = new Handler(Looper.getMainLooper());
    static final int INK = Color.parseColor("#3A2530");
    static final int BG = Color.parseColor("#FFF7FA");

    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    void save() {
        try { sp.edit().putString("brain", b.toJson().toString()).apply(); } catch (Exception e) { }
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override protected void onCreate(Bundle st) {
        super.onCreate(st);
        sp = getSharedPreferences("baby", MODE_PRIVATE);
        String raw = sp.getString("brain", null);
        if (raw != null) {
            try { b.fromJson(new JSONObject(raw)); } catch (Exception e) { b = new Brain(); }
        }
        if (b.name.isEmpty()) showBirth(); else openChat();
    }

    @Override protected void onPause() {
        super.onPause();
        if (!b.name.isEmpty()) { b.lastSeen = System.currentTimeMillis(); save(); }
    }

    @Override protected void onResume() {
        super.onResume();
        if (!b.name.isEmpty() && msgs != null) {
            String w = b.welcomeBack();
            if (w != null) { b.addChat("b", w); bubble(false, w); header(); save(); }
        }
    }

    TextView tv(String t, int size) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(size); v.setTextColor(INK); v.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(8));
        v.setLayoutParams(lp);
        return v;
    }

    void showBirth() {
        msgs = null;
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER);
        r.setPadding(dp(28), dp(28), dp(28), dp(28));
        r.setBackgroundColor(BG);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        r.setFitsSystemWindows(true);
        TextView t = tv("یک دختر کوچولو تازه به دنیا اومده", 20);
        t.setTypeface(null, Typeface.BOLD);
        EditText n = new EditText(this);
        n.setHint("اسمش چی باشه؟");
        n.setGravity(Gravity.CENTER);
        n.setSingleLine(true);
        n.setTextColor(INK);
        Button go = new Button(this);
        go.setText("به دنیا بیار 💗");
        go.setOnClickListener(v -> {
            String nm = n.getText().toString().trim();
            if (nm.isEmpty()) return;
            b = new Brain();
            b.name = nm;
            b.born = System.currentTimeMillis();
            b.lastSeen = b.born;
            b.addChat("b", b.firstSound());
            save();
            openChat();
        });
        r.addView(tv("🍼", 64));
        r.addView(t);
        r.addView(tv("هیچی نمی‌دونه. فقط می‌دونه تازه به دنیا اومده و دختره. تو اولین کسی هستی که می‌بینه. اسمش رو تو انتخاب کن.", 14));
        r.addView(n, new LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT));
        r.addView(go);
        setContentView(r);
    }

    Button qbtn(String label, Runnable run) {
        Button x = new Button(this);
        x.setText(label);
        x.setTextSize(12);
        x.setAllCaps(false);
        x.setPadding(0, 0, 0, 0);
        x.setOnClickListener(v -> run.run());
        return x;
    }

    void openChat() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setFitsSystemWindows(true);

        LinearLayout hd = new LinearLayout(this);
        hd.setOrientation(LinearLayout.HORIZONTAL);
        hd.setGravity(Gravity.CENTER_VERTICAL);
        hd.setPadding(dp(14), dp(10), dp(14), dp(10));
        hd.setBackgroundColor(Color.WHITE);
        face = new TextView(this);
        face.setTextSize(34);
        LinearLayout tl = new LinearLayout(this);
        tl.setOrientation(LinearLayout.VERTICAL);
        title = new TextView(this);
        title.setTextSize(17); title.setTypeface(null, Typeface.BOLD); title.setTextColor(INK);
        status = new TextView(this);
        status.setTextSize(12); status.setTextColor(Color.parseColor("#8A6F7A"));
        tl.addView(title); tl.addView(status);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.setMargins(dp(10), 0, dp(10), 0);
        Button menu = new Button(this);
        menu.setText("🧠 منو");
        menu.setAllCaps(false);
        menu.setOnClickListener(v -> menu());
        hd.addView(face); hd.addView(tl, tlp); hd.addView(menu);
        root.addView(hd);

        sv = new ScrollView(this);
        msgs = new LinearLayout(this);
        msgs.setOrientation(LinearLayout.VERTICAL);
        msgs.setPadding(dp(12), dp(8), dp(12), dp(8));
        sv.addView(msgs);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout qb = new LinearLayout(this);
        qb.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        qb.addView(qbtn("🍼 شیر", () -> action("🍼 بهش شیر دادی", b.feed())), qp);
        qb.addView(qbtn("🤗 بغل", () -> action("🤗 بغلش کردی", b.hug())), qp);
        qb.addView(qbtn("🎈 بازی", () -> action("🎈 باهاش بازی کردی", b.play())), qp);
        qb.addView(qbtn("😴 خواب", () -> action("😴 خوابوندیش", b.sleep())), qp);
        root.addView(qb);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(4), dp(8), dp(8));
        input = new EditText(this);
        input.setHint("با من حرف بزن...");
        input.setTextColor(INK);
        input.setSingleLine(true);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        input.setOnEditorActionListener((v, a, ev) -> { send(); return true; });
        Button sendB = new Button(this);
        sendB.setText("بگو");
        sendB.setOnClickListener(v -> send());
        row.addView(input, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(sendB);
        root.addView(row);

        setContentView(root);
        for (String[] m : b.chat) {
            if (m[0].equals("s")) sys(m[1]); else bubble(m[0].equals("u"), m[1]);
        }
        header();
    }

    void header() {
        if (face == null) return;
        face.setText(b.faceEmoji());
        title.setText(b.name);
        status.setText(b.status());
    }

    void bubble(boolean mine, String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(15);
        v.setTextColor(INK);
        v.setPadding(dp(12), dp(8), dp(12), dp(8));
        v.setMaxWidth(dp(290));
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(16));
        g.setColor(Color.parseColor(mine ? "#FFD9E6" : "#FFFFFF"));
        if (!mine) g.setStroke(dp(1), Color.parseColor("#F0D5DE"));
        v.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = mine ? Gravity.START : Gravity.END;
        lp.setMargins(0, dp(4), 0, dp(4));
        msgs.addView(v, lp);
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
    }

    void sys(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(12);
        v.setTextColor(Color.parseColor("#8A6F7A"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.setMargins(0, dp(6), 0, dp(6));
        msgs.addView(v, lp);
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
    }

    void babySay(String t) {
        b.addChat("b", t);
        save();
        h.postDelayed(() -> { bubble(false, t); header(); }, 500);
    }

    void send() {
        String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        input.setText("");
        b.addChat("u", t);
        bubble(true, t);
        babySay(b.reply(t));
    }

    void action(String label, String reply) {
        b.addChat("s", label);
        sys(label);
        babySay(reply);
    }

    void menu() {
        String[] items = {"🧠 چی یاد گرفته؟", "💾 کپی پشتیبان", "📥 بازیابی از کلیپ‌بورد", "🗑 پاک کردن و تولد دوباره"};
        new AlertDialog.Builder(this).setItems(items, (d, i) -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            switch (i) {
                case 0:
                    new AlertDialog.Builder(this).setTitle(b.name).setMessage(b.knowledge())
                            .setPositiveButton("باشه", null).show();
                    break;
                case 1:
                    try {
                        cm.setPrimaryClip(ClipData.newPlainText("baby", b.toJson().toString()));
                        toast("کپی شد. جایی مثل یادداشت‌ها ذخیره‌اش کن.");
                    } catch (Exception e) { toast("نشد"); }
                    break;
                case 2:
                    try {
                        String raw = cm.getPrimaryClip().getItemAt(0).getText().toString();
                        Brain nb = new Brain();
                        nb.fromJson(new JSONObject(raw));
                        if (nb.name.isEmpty()) throw new Exception("bad");
                        b = nb;
                        save();
                        openChat();
                        toast("بازیابی شد");
                    } catch (Exception e) { toast("متن کپی‌شده معتبر نیست"); }
                    break;
                case 3:
                    new AlertDialog.Builder(this).setMessage("همه‌چیز پاک می‌شه. مطمئنی؟")
                            .setPositiveButton("آره", (d2, w) -> {
                                b = new Brain();
                                sp.edit().clear().apply();
                                showBirth();
                            })
                            .setNegativeButton("نه", null).show();
                    break;
            }
        }).show();
    }
}
